package com.kiet.orders;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Creates connections to the MySQL ecommerce_db database.
 * Configure DB_PASSWORD as an environment variable before running.
 */
public final class DBConnection {
    private static final String DEFAULT_URL =
            "jdbc:mysql://localhost:3306/ecommerce_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_USER = "root";

    private DBConnection() {
        // Utility class; do not instantiate.
    }

    public static Connection getConnection() throws SQLException {
        String url = System.getenv().getOrDefault("DB_URL", DEFAULT_URL);
        String user = System.getenv().getOrDefault("DB_USER", DEFAULT_USER);
        String password = System.getenv("DB_PASSWORD");

        if (password == null) {
            throw new SQLException("DB_PASSWORD environment variable is not set. Configure it in IntelliJ Run Configuration.");
        }

        return DriverManager.getConnection(url, user, password);
    }
}
