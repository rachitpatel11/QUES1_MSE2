package com.kiet.orders;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.List;

/** Contains all database operations for the Orders table. */
public class OrderDAO {
    private static final String[] VALID_STATUSES = {"Pending", "Shipped", "Delivered"};

    public void insertSampleOrders() throws SQLException {
        String sql = "INSERT INTO Orders (order_id, customer_name, product_name, quantity, unit_price, status) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        Order[] samples = {
                new Order(1001, "Aarav", "Keyboard", 3, 799.00, "Pending"),
                new Order(1002, "Diya", "Mouse", 5, 499.00, "Shipped"),
                new Order(1003, "Kabir", "Monitor", 1, 8999.00, "Cancelled")
        };

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            for (Order order : samples) {
                statement.setInt(1, order.getOrderId());
                statement.setString(2, order.getCustomerName());
                statement.setString(3, order.getProductName());
                statement.setInt(4, order.getQuantity());
                statement.setDouble(5, order.getUnitPrice());
                statement.setString(6, order.getStatus());

                try {
                    int rows = statement.executeUpdate();
                    if (rows > 0) {
                        System.out.println("Inserted order ID " + order.getOrderId() + ".");
                    }
                } catch (SQLIntegrityConstraintViolationException ex) {
                    System.out.println("Order ID " + order.getOrderId()
                            + " already exists. Skipping duplicate.");
                } catch (SQLException ex) {
                    // MySQL duplicate-key error code is 1062. Handle it without hiding other SQL errors.
                    if (ex.getErrorCode() == 1062) {
                        System.out.println("Order ID " + order.getOrderId()
                                + " already exists. Skipping duplicate.");
                    } else {
                        throw ex;
                    }
                }
            }
        }
    }

    public List<Order> searchOrdersByStatus(String status) throws SQLException {
        String sql = "SELECT order_id, customer_name, product_name, quantity, unit_price, status "
                   + "FROM Orders WHERE status = ? AND quantity > 2 ORDER BY unit_price DESC";
        List<Order> orders = new ArrayList<>();

        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, status);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    orders.add(readOrder(resultSet));
                }
            }
        }
        return orders;
    }

    public boolean increaseQuantity(int orderId, int additionalQuantity) throws SQLException {
        String sql = "UPDATE Orders SET quantity = quantity + ? WHERE order_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, additionalQuantity);
            statement.setInt(2, orderId);
            return statement.executeUpdate() > 0;
        }
    }

    public Order updateStatus(int orderId, String newStatus) throws SQLException {
        if (!isValidStatus(newStatus)) {
            return null;
        }

        Order existingOrder = findById(orderId);
        if (existingOrder == null) {
            return null;
        }

        String sql = "UPDATE Orders SET status = ? WHERE order_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, canonicalStatus(newStatus));
            statement.setInt(2, orderId);
            statement.executeUpdate();
        }
        return findById(orderId);
    }

    public Order findById(int orderId) throws SQLException {
        String sql = "SELECT order_id, customer_name, product_name, quantity, unit_price, status "
                   + "FROM Orders WHERE order_id = ?";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderId);
            try (ResultSet resultSet = statement.executeQuery()) {
                return resultSet.next() ? readOrder(resultSet) : null;
            }
        }
    }

    public double getTotalOrderValue() throws SQLException {
        String sql = "SELECT COALESCE(SUM(quantity * unit_price), 0) AS total_value FROM Orders";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            resultSet.next();
            return resultSet.getDouble("total_value");
        }
    }

    public boolean deleteIfCancelled(int orderId) throws SQLException {
        String sql = "DELETE FROM Orders WHERE order_id = ? AND status = 'Cancelled'";
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, orderId);
            return statement.executeUpdate() > 0;
        }
    }

    public boolean isValidStatus(String status) {
        if (status == null) {
            return false;
        }
        for (String validStatus : VALID_STATUSES) {
            if (validStatus.equalsIgnoreCase(status.trim())) {
                return true;
            }
        }
        return false;
    }

    private String canonicalStatus(String status) {
        for (String validStatus : VALID_STATUSES) {
            if (validStatus.equalsIgnoreCase(status.trim())) {
                return validStatus;
            }
        }
        throw new IllegalArgumentException("Invalid order status: " + status);
    }

    private Order readOrder(ResultSet resultSet) throws SQLException {
        return new Order(
                resultSet.getInt("order_id"),
                resultSet.getString("customer_name"),
                resultSet.getString("product_name"),
                resultSet.getInt("quantity"),
                resultSet.getDouble("unit_price"),
                resultSet.getString("status"));
    }
}
