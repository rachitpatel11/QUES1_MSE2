package com.kiet.orders;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/** Console menu for the Order Management System. */
public class Main {
    private static final Scanner SCANNER = new Scanner(System.in);
    private static final OrderDAO ORDER_DAO = new OrderDAO();

    public static void main(String[] args) {
        System.out.println("Welcome to the Order Management System (JDBC + MySQL).");

        boolean running = true;
        while (running) {
            printMenu();
            int choice = readInt("Enter your choice: ");

            try {
                switch (choice) {
                    case 1 -> ORDER_DAO.insertSampleOrders();
                    case 2 -> searchOrders();
                    case 3 -> increaseQuantity();
                    case 4 -> updateStatus();
                    case 5 -> System.out.printf("Total order value: %.2f%n",
                            ORDER_DAO.getTotalOrderValue());
                    case 6 -> deleteOrder();
                    case 7 -> {
                        running = false;
                        System.out.println("Exiting. Goodbye!");
                    }
                    default -> System.out.println("Invalid menu choice. Please select 1 to 7.");
                }
            } catch (SQLException ex) {
                System.out.println("Database operation failed: " + ex.getMessage());
                System.out.println("Check that MySQL is running, schema.sql was executed, and DB settings are correct.");
            }
            System.out.println();
        }
        SCANNER.close();
    }

    private static void printMenu() {
        System.out.println("===== ORDER MANAGEMENT SYSTEM =====");
        System.out.println("1. Insert three sample orders");
        System.out.println("2. Search orders by status");
        System.out.println("3. Increase order quantity");
        System.out.println("4. Update order status");
        System.out.println("5. Display total order value");
        System.out.println("6. Delete order (only if Cancelled)");
        System.out.println("7. Exit");
    }

    private static void searchOrders() throws SQLException {
        System.out.print("Enter order status: ");
        String status = SCANNER.nextLine().trim();
        if (status.isEmpty()) {
            System.out.println("Status cannot be empty.");
            return;
        }

        List<Order> orders = ORDER_DAO.searchOrdersByStatus(status);
        if (orders.isEmpty()) {
            System.out.println("No matching orders found.");
        } else {
            System.out.println("Matching orders (quantity > 2, unit price descending):");
            orders.forEach(System.out::println);
        }
    }

    private static void increaseQuantity() throws SQLException {
        int orderId = readInt("Enter order ID: ");
        int additionalQuantity = readInt("Enter additional quantity: ");
        if (additionalQuantity <= 0) {
            System.out.println("Additional quantity must be positive.");
            return;
        }

        if (ORDER_DAO.increaseQuantity(orderId, additionalQuantity)) {
            System.out.println("Order quantity increased successfully.");
            System.out.println(ORDER_DAO.findById(orderId));
        } else {
            System.out.println("Order ID " + orderId + " does not exist.");
        }
    }

    private static void updateStatus() throws SQLException {
        int orderId = readInt("Enter order ID: ");
        System.out.print("Enter new status (Pending/Shipped/Delivered): ");
        String status = SCANNER.nextLine().trim();

        if (!ORDER_DAO.isValidStatus(status)) {
            System.out.println("Invalid status. Allowed values: Pending, Shipped, Delivered.");
            return;
        }

        Order updatedOrder = ORDER_DAO.updateStatus(orderId, status);
        if (updatedOrder == null) {
            System.out.println("Order ID " + orderId + " does not exist.");
        } else {
            System.out.println("Order status updated successfully:");
            System.out.println(updatedOrder);
        }
    }

    private static void deleteOrder() throws SQLException {
        int orderId = readInt("Enter order ID to delete: ");
        Order existingOrder = ORDER_DAO.findById(orderId);
        if (existingOrder == null) {
            System.out.println("Order ID " + orderId + " does not exist.");
        } else if (!"Cancelled".equalsIgnoreCase(existingOrder.getStatus())) {
            System.out.println("Order cannot be deleted because its status is "
                    + existingOrder.getStatus() + ", not Cancelled.");
        } else if (ORDER_DAO.deleteIfCancelled(orderId)) {
            System.out.println("Cancelled order deleted successfully.");
        } else {
            System.out.println("Order was not deleted. Please try again.");
        }
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = SCANNER.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException ex) {
                System.out.println("Please enter a valid whole number.");
            }
        }
    }
}
