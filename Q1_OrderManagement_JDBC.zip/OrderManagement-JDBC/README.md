# Order Management System — Java JDBC + MySQL

A beginner-friendly, menu-driven Java 17 project for the KIET CS336B MSE-II Q1 assignment.

## Project structure

```text
OrderManagement-JDBC/
├── pom.xml
├── README.md
├── database/
│   └── schema.sql
└── src/main/java/com/kiet/orders/
    ├── Main.java
    ├── DBConnection.java
    ├── Order.java
    └── OrderDAO.java
```

## 1. Install and use JDK 17

1. Install a JDK 17 distribution (for example, Eclipse Temurin 17).
2. In a terminal, run `java -version` and confirm it reports version 17.
3. In IntelliJ IDEA, open **File → Project Structure → Project** and set the Project SDK to JDK 17.

## 2. Set up MySQL

1. Install MySQL Server and MySQL Workbench.
2. Start the MySQL server.
3. Keep your MySQL username and password available. This project does not contain a real password.

## 3. Run `schema.sql` in MySQL Workbench

1. Open MySQL Workbench and connect to your local server.
2. Open `database/schema.sql` from this project.
3. Execute the script (lightning-bolt button).
4. Confirm that the `ecommerce_db` schema and `Orders` table appear in the Schemas panel.

The SQL creates the database and table if they do not already exist. It does not delete existing data.

## 4. Configure database environment variables in IntelliJ

Open **Run → Edit Configurations…**, select the application configuration for `Main`, and add these environment variables:

```text
DB_URL=jdbc:mysql://localhost:3306/ecommerce_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC
DB_USER=root
DB_PASSWORD=your_actual_mysql_password
```

Replace `your_actual_mysql_password` with your local MySQL password. Do not commit or share that password.

`DB_URL` defaults to the URL above and `DB_USER` defaults to `root` if omitted. `DB_PASSWORD` is deliberately required and has no hardcoded default. If your MySQL username is not `root`, set `DB_USER` to your username.

## 5. Open the project in IntelliJ IDEA

1. Choose **File → Open** and select the `OrderManagement-JDBC` folder (the folder containing `pom.xml`).
2. If prompted, choose **Load Maven Project**.
3. Wait for Maven to download MySQL Connector/J.
4. Ensure the Project SDK is JDK 17.

## 6. Run `Main.java`

Open `src/main/java/com/kiet/orders/Main.java` and click the green Run icon beside `main`. Keep the MySQL server running.

Alternatively, from the project folder, run:

```bash
mvn clean compile
mvn exec:java
```

Set the three environment variables in the terminal before running Maven if you use the command-line method.

## 7. Test every menu option

Start with a fresh table (or note which sample IDs already exist).

1. **Insert samples:** choose `1`. Orders 1001, 1002, and 1003 are inserted. Choose `1` again to confirm duplicate IDs are skipped gracefully.
2. **Search:** choose `2`, enter `Pending`. The search only returns matching orders with quantity greater than 2 and sorts by unit price descending. Try `Shipped` as well.
3. **Increase quantity:** choose `3`, enter order ID `1001`, then additional quantity `2`. The quantity should change from 3 to 5. Try an unknown ID and a zero/negative amount to see validation.
4. **Update status:** choose `4`, enter order ID `1001`, then `Delivered`. The updated order should be printed. Try an invalid status such as `Processing`, and a nonexistent ID.
5. **Total value:** choose `5`. The application displays `SUM(quantity * unit_price)` for all rows.
6. **Conditional delete:** choose `6`, enter `1001` (not Cancelled) to confirm deletion is refused. Then enter `1003` (Cancelled) to delete it. Try `1003` again to confirm the missing-order message.
7. Choose `7` to exit.

The sample data starts with a total value of **13,891.00**.

## 8. Troubleshooting

- **`DB_PASSWORD environment variable is not set`:** Add `DB_PASSWORD` to the IntelliJ Run Configuration's Environment variables field, then run again.
- **`Communications link failure` / connection refused:** Ensure MySQL Server is running and `DB_URL` has the correct host and port (default port is 3306).
- **`Access denied for user`:** Check `DB_USER` and `DB_PASSWORD`; verify that the account can connect to MySQL.
- **`Unknown database 'ecommerce_db'`:** Execute `database/schema.sql` in MySQL Workbench.
- **`Table 'ecommerce_db.Orders' doesn't exist`:** Confirm the SQL script completed successfully and that the active schema is `ecommerce_db`.
- **Maven dependency download failure:** Check internet connectivity and reload the Maven project in IntelliJ.
- **Port differs from 3306:** Update `DB_URL` to use your configured MySQL port.

## Implementation notes

- All SQL statements use `PreparedStatement`; all user-provided values are bound as parameters.
- Database resources use try-with-resources.
- Duplicate sample IDs are reported and skipped; other SQL errors are not silently ignored.
- Only `Pending`, `Shipped`, and `Delivered` are accepted by the status-update operation. The sample `Cancelled` value is retained for the conditional-delete requirement.
- Deletion includes `status = 'Cancelled'` in the SQL `WHERE` clause, so a non-cancelled row cannot be deleted by this operation.
- A real MySQL server connection is required to exercise database operations; compiling the project alone does not test a live database.
